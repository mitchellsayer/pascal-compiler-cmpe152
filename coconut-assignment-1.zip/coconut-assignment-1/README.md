# Pascal Scanner

To run our project, first build the code by running:
``` make ```

And run the scanner by specifying an input and output filepath:
``` ./scanner INPUT_FILE_PATH OUTPUT_FILE_PATH ```

Note that the filepaths must be relative and the output file does not have to exist when the scanner is run.